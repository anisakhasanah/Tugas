package com.example.tampilnama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listvMahasiswa;
    private List<NamaMahasiswa> namaMahasiswas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listvMahasiswa=(ListView) findViewById(R.id.listviewmahasiswa);
//        historiList=new ArrayList<>();
        namaMahasiswas=new ArrayList<>();
        namaMahasiswas.clear();
        namaMahasiswas.add(new NamaMahasiswa("Nama Satu","SSI202202851"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Dua","SSI202202852"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Tiga","SSI202202853"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Empat","SSI202202854"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Lima","SSI202202855"));
        namaMahasiswas.add(new NamaMahasiswa("Anisa UI Khasanah","SSI202202856"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Tujuh","SSI202202857"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Delapan","SSI202202858"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Sembilan","SSI202202859"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Sepuluh","SSI202202860"));
        namaMahasiswas.add(new NamaMahasiswa("Nama Sebelas","SSI202202861"));
        MahasiswaList mahasiswaList=new MahasiswaList(MainActivity.this,namaMahasiswas);
        listvMahasiswa.setAdapter(mahasiswaList);
//        namaMahasiswas.add(0, new String[Integer.parseInt("Nim Satu")]));



    }
}