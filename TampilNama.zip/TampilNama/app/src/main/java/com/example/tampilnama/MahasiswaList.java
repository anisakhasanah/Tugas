package com.example.tampilnama;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MahasiswaList extends ArrayAdapter<NamaMahasiswa> {
    private Activity context;
    private List<NamaMahasiswa> namaMahasiswas;
    public MahasiswaList(Activity context,List<NamaMahasiswa> namaMahasiswas) {
        super(context,R.layout.mahasiswa_layout,namaMahasiswas);
        this.context = context;
        this.namaMahasiswas=namaMahasiswas;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.mahasiswa_layout, null, true);

        TextView textnim = (TextView) listViewItem.findViewById(R.id.tnim);
        TextView textnama = (TextView) listViewItem.findViewById(R.id.tnama);

        NamaMahasiswa namaMahasiswa=namaMahasiswas.get(position);
        textnim.setText(namaMahasiswa.getNim());
        textnama.setText(namaMahasiswa.getNama());

        return listViewItem;
    }
}
